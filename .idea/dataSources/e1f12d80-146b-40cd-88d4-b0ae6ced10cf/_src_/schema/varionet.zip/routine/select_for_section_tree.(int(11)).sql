CREATE PROCEDURE select_for_section_tree(IN `_system_id` INT)
  BEGIN

	SELECT type, permission, number
	FROM section
	WHERE system_id = _system_id;

END;
