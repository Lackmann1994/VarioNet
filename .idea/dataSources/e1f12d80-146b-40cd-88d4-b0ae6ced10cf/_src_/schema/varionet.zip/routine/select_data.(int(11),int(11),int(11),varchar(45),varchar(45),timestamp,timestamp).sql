CREATE PROCEDURE select_data(IN `_client_id`  INT, IN `_system_id` INT, IN `_sub_section` INT,
                             IN `_data_name2` VARCHAR(45), IN `_data_section` VARCHAR(45), IN `_time_from` TIMESTAMP,
                             IN `_time_to`    TIMESTAMP)
  BEGIN
	
    IF _time_from is NULL
		THEN SET _time_from = '2000-01-01 00:00:00';
    END IF;
    
	IF _time_to is NULL
		THEN SET _time_to = NOW();
    END IF;

	SELECT
		data_value, 
        timestamp,
		IFNULL(LENGTH(array_type) - LENGTH(REPLACE(array_type, ':', ''))+1, 0)  as length,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 1), ':', -1) as array_type_0,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 2), ':', -1) as array_type_1,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 3), ':', -1) as array_type_2,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 4), ':', -1) as array_type_3,
        system_defines_0.define_value as array_length_0,
        system_defines_1.define_value as array_length_1,
        system_defines_2.define_value as array_length_2,
        system_defines_3.define_value as array_length_3
	FROM data
	LEFT JOIN data_type ON data.data_type_id = data_type.id
    LEFT JOIN system_defines as system_defines_0 ON system_defines_0.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 1), ':', -1)
    LEFT JOIN system_defines as system_defines_1 ON system_defines_1.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 2), ':', -1)
    LEFT JOIN system_defines as system_defines_2 ON system_defines_2.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 3), ':', -1)
    LEFT JOIN system_defines as system_defines_3 ON system_defines_3.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 4), ':', -1)
	WHERE client_id = _client_id
	AND data.system_id = _system_id
	AND (sub_section = _sub_section OR sub_section IS NULL)
	AND data_name2 = _data_name2
	AND data_section = _data_section
	AND timestamp BETWEEN _time_from AND _time_to;

END;
