CREATE PROCEDURE update_last_login(IN id INT)
  BEGIN

	UPDATE `varionet`.`client` SET `last_login`=now() WHERE `id`=id;

END;
