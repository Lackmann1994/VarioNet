CREATE PROCEDURE select_password_hash_client(IN `_id` INT)
  BEGIN

	SELECT password_hash
	From client
	WHERE id = _id;


END;
