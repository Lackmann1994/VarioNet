CREATE PROCEDURE insert_data(IN `_data_name2` VARCHAR(45), IN `_data_section` VARCHAR(45), IN `_data_value` JSON,
                             IN `_client_id`  INT, IN `_system_id` INT, IN `_sub_section` INT)
  BEGIN

	INSERT INTO `varionet`.`data` (`data_type_id`, `data_value`, `client_id`, `system_id`, `sub_section`)
	SELECT id, _data_value, _client_id, _system_id, _sub_section
	FROM data_type
	WHERE data_name2 = _data_name2
	AND data_section = _data_section
	LIMIT 1;


END;
