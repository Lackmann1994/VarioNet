CREATE PROCEDURE insert_client(IN `_firstname`          VARCHAR(45), IN `_lastname` VARCHAR(45),
                               IN `_email`              VARCHAR(45), IN `_super_client` VARCHAR(45),
                               IN `_logo`               BINARY(1), IN `_logout_timer` INT, IN `_street` VARCHAR(45),
                               IN `_street_nr`          INT, IN `_postcode` INT, IN `_town` VARCHAR(45),
                               IN `_region`             VARCHAR(45), IN `_number` INT,
                               IN `_description_intern` VARCHAR(45), IN `_description_extern` VARCHAR(45),
                               IN `_password_hash`      VARCHAR(255), IN `_lat` FLOAT(10, 6), IN `_lng` FLOAT(10, 6))
  BEGIN

DECLARE _coordinate POINT;
SET _coordinate = GeomFromText(CONCAT('POINT(',_lat, ' ', _lng,')'));

INSERT INTO address (street, street_nr, postcode, town, region, number, coordinate)
     VALUES (_street, _street_nr, _postcode, _town, _region, _number, _coordinate);
INSERT INTO client (firstname, lastname, password_hash, email, super_client, logo, logout_timer, address_id, description_intern, description_extern)
     VALUES (_firstname, _lastname, _password_hash, _email, _super_client, _logo, _logout_timer, LAST_INSERT_ID(), _description_intern, _description_extern);


END;
