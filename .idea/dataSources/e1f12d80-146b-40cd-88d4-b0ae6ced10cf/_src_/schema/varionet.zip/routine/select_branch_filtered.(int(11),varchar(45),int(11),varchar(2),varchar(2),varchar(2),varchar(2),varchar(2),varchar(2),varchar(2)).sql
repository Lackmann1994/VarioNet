CREATE PROCEDURE select_branch_filtered(IN branchroot   INT, IN filter VARCHAR(45), IN filter_range INT,
                                        IN client_id_on VARCHAR(2), IN firstname_on VARCHAR(2),
                                        IN lastname_on  VARCHAR(2), IN street_on VARCHAR(2), IN postcode_on VARCHAR(2),
                                        IN town_on      VARCHAR(2), IN number_on VARCHAR(2))
  BEGIN
	
    SELECT branch.id 
    FROM(
		SELECT c2.* 
        FROM client c, client c2, client_path p, client_path p2
		WHERE c.id = branchroot 
        AND	p2.client_id = c.id 
        AND	p.path LIKE(CONCAT(p2.path,'%')) 
		AND c2.id = p.client_id) AS branch
	LEFT JOIN address ON branch.address_id = address.id 
	WHERE client_id_on = 'on' AND levenshtein(filter, branch.id) between 0 and filter_range
	OR firstname_on = 'on' AND levenshtein(filter, firstname) between 0 and filter_range
	OR lastname_on= 'on' AND levenshtein(filter, lastname) between 0 and filter_range
	OR street_on = 'on' AND levenshtein(filter, street) between 0 and filter_range
	OR postcode_on = 'on' AND levenshtein(filter, postcode) between 0 and filter_range
	OR town_on = 'on' AND levenshtein(filter, town) between 0 and filter_range
	OR number_on = 'on' AND levenshtein(filter, number) between 0 and filter_range;

END;
