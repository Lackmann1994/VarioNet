CREATE PROCEDURE update_client(IN `_id`                 INT, IN `_firstname` VARCHAR(45), IN `_lastname` VARCHAR(45),
                               IN `_email`              VARCHAR(45), IN `_super_client` INT, IN `_logo` BLOB,
                               IN `_logout_timer`       INT, IN `_street` VARCHAR(45), IN `_street_nr` INT,
                               IN `_postcode`           INT, IN `_town` VARCHAR(45), IN `_region` VARCHAR(45),
                               IN `_number`             INT, IN `_description_intern` VARCHAR(45),
                               IN `_description_extern` VARCHAR(45), IN `_lat` FLOAT(10, 6), IN `_lng` FLOAT(10, 6))
  BEGIN

DECLARE _coordinate POINT;
SET _coordinate = GeomFromText(CONCAT('POINT(',_lat, ' ', _lng,')'));

      UPDATE client
      LEFT JOIN address ON address_id = address.id  
      SET firstname = _firstname,
          lastname = _lastname,
          email = _email,
          super_client = _super_client,
          logo = _logo,
          logout_timer = _logout_timer,
          description_intern = _description_intern,
          description_extern = _description_extern,
          street = _street,
          street_nr= _street_nr,
          postcode = _postcode,
          region = _region,
          town = _town,
          number = _number,
          coordinate = _coordinate
      WHERE client.id = _id;

END;
