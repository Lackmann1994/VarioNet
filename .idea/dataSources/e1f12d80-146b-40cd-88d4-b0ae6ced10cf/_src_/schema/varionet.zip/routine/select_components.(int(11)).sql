CREATE PROCEDURE select_components(IN `_id` INT)
  BEGIN

SELECT *
FROM component
WHERE system_id = _id;

END;
