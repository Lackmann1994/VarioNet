CREATE PROCEDURE select_name_coordinate(IN `_id` INT)
  BEGIN

	SELECT 
		client.id, 
		CONCAT_WS(" ", `firstname`, `lastname`) AS `name`,
		ST_X(coordinate) AS latitude,
        ST_Y(coordinate) AS longitude
    FROM `client`
    LEFT JOIN address ON address_id = address.id 
    WHERE client.id = _id;

END;
