CREATE PROCEDURE select_password_hash_system(IN `_id` INT)
  BEGIN

	SELECT password_hash
	From system
	WHERE id = _id;


END;
