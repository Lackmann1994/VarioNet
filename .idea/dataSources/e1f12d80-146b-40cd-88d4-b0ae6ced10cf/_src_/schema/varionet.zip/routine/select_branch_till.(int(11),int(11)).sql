CREATE PROCEDURE select_branch_till(IN branchroot INT, IN till INT)
  BEGIN

	SELECT client.id as id, super_client, path, CONCAT_WS(" ", firstname, lastname) AS `name`
	FROM client
	LEFT JOIN client_path ON client.id = client_id
	WHERE path like(CONCAT((
		SELECT path 
		FROM client
		LEFT JOIN client_path ON client.id = client_id
		WHERE client.id = branchroot), '%'))
	AND NOT path like(CONCAT((
		SELECT path 
		FROM client
		LEFT JOIN client_path ON client.id = client_id
		WHERE client.id = till), '%'));

END;
