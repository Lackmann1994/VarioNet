CREATE PROCEDURE update_default_language(IN `_client_id` INT, IN `_default_language` VARCHAR(2))
  BEGIN

	UPDATE `varionet`.`client`
	SET `default_language` = _default_language
	WHERE `id` = _id;


END;
