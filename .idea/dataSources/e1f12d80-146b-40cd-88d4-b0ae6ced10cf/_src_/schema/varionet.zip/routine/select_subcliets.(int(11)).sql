CREATE PROCEDURE select_subcliets(IN branchroot INT)
  BEGIN
	SELECT id
    FROM client 
    WHERE super_client = branchroot;

END;
