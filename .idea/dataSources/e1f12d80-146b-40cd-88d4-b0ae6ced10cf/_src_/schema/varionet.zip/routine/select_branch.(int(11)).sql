CREATE PROCEDURE select_branch(IN branchroot INT)
  BEGIN
	/* some comment
     *
     */
	SELECT c2.id, c2.super_client, CONCAT_WS(" ", c2.firstname, c2.lastname) AS `name` FROM
	client c, client c2, client_path p, client_path p2
	WHERE c.id = branchroot AND
		p2.client_id = c.id AND
		p.path LIKE(CONCAT(p2.path,'%')) AND
		c2.id = p.client_id;

END;
