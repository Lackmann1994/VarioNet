CREATE PROCEDURE delete_component(IN `_id` INT)
  BEGIN

	DELETE FROM `varionet`.`component`
	WHERE id = _id;

END;
