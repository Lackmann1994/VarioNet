CREATE PROCEDURE delete_client(IN `_id` INT)
  BEGIN

	DELETE FROM client WHERE id= _id;

END;
