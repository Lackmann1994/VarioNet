CREATE PROCEDURE select_system_inputs()
  BEGIN

SELECT * 
FROM(
	SELECT COLUMN_NAME, COLUMN_COMMENT, COLUMN_DEFAULT
	FROM `information_schema`.`columns` 
	WHERE `table_schema` = 'varionet' 
    AND `table_name` in ('system', 'address')
    ORDER BY COLUMN_COMMENT ASC) as a
WHERE LENGTH(COLUMN_COMMENT) > 0;
END;
