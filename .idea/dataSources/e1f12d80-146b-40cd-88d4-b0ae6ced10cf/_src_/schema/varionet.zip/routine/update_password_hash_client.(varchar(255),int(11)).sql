CREATE PROCEDURE update_password_hash_client(IN `_password_hash` VARCHAR(255), IN `_id` INT)
  BEGIN

	UPDATE client
	SET password_hash = _password_hash
	WHERE id= _id;


END;
