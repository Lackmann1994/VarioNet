CREATE PROCEDURE select_array_types(IN `_data_section` VARCHAR(45))
  BEGIN

	SELECT 
		data_name,
		data_name2,
		config_group,
		permission,
		data_type,
		data_name_de,
		data_name_en, 
		data_name_fr,
		data_tooltip_de, 
		data_tooltip_en, 
		data_tooltip_fr, 
		data_coefficient, 
		data_min_val, 
		data_max_val, 
		data_unit,
		IFNULL(LENGTH(array_type) - LENGTH(REPLACE(array_type, ':', ''))+1, 0)  as length,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 1), ':', -1) as array_type_0,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 2), ':', -1) as array_type_1,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 3), ':', -1) as array_type_2,
		SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 4), ':', -1) as array_type_3,
        system_defines_0.define_value as array_length_0,
        system_defines_1.define_value as array_length_1,
        system_defines_2.define_value as array_length_2,
        system_defines_3.define_value as array_length_3
	FROM data_type
    LEFT JOIN system_defines as system_defines_0 ON system_defines_0.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 1), ':', -1)
    LEFT JOIN system_defines as system_defines_1 ON system_defines_1.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 2), ':', -1)
    LEFT JOIN system_defines as system_defines_2 ON system_defines_2.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 3), ':', -1)
    LEFT JOIN system_defines as system_defines_3 ON system_defines_3.define_name = SUBSTRING_INDEX(SUBSTRING_INDEX(array_type, ':', 4), ':', -1)
	WHERE data_section = _data_section
    AND config_group IS NOT NULL;

END;
