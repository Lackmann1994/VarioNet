CREATE PROCEDURE select_system(IN `_id` INT)
  BEGIN
	SELECT
		INET_NTOA(ip_address) AS ip_address,
        client_id,
        status,
        on_top_10m,
        washing,
        dryer,
        
        control,
        switch_cabinet,
        display,
        qt,
        image,
        link,
        
        street,
        street_nr,
        postcode,
        town,
        region,
        number,
        
        description_intern,
        description_extern
    FROM system
    LEFT JOIN address ON address_id = address.id
    WHERE system.id = _id;

END;
