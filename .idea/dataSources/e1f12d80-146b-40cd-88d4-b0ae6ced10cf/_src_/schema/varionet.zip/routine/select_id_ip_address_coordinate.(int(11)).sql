CREATE PROCEDURE select_id_ip_address_coordinate(IN id INT)
  BEGIN

	SELECT
		system.id,
		INET_NTOA(ip_address) AS ip_address,
        X(coordinate) AS latitude,
        Y(coordinate) AS longitude
    FROM system
    LEFT JOIN address ON address_id = address.id
    WHERE client_id = id;

END;
