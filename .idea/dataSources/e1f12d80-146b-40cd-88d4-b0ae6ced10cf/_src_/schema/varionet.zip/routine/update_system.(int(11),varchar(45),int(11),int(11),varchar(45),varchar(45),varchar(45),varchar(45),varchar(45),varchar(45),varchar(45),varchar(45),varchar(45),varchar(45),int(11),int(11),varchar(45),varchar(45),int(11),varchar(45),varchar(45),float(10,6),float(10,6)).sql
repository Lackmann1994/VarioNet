CREATE PROCEDURE update_system(IN `_id`                 INT, IN `_ip_address` VARCHAR(45), IN `_client_id` INT,
                               IN `_status`             INT, IN `_on_top_10m` VARCHAR(45), IN `_washing` VARCHAR(45),
                               IN `_dryer`              VARCHAR(45), IN `_control` VARCHAR(45),
                               IN `_switch_cabinet`     VARCHAR(45), IN `_display` VARCHAR(45), IN `_qt` VARCHAR(45),
                               IN `_image`              VARCHAR(45), IN `_link` VARCHAR(45), IN `_street` VARCHAR(45),
                               IN `_street_nr`          INT, IN `_postcode` INT, IN `_town` VARCHAR(45),
                               IN `_region`             VARCHAR(45), IN `_number` INT,
                               IN `_description_intern` VARCHAR(45), IN `_description_extern` VARCHAR(45),
                               IN `_lat`                FLOAT(10, 6), IN `_lng` FLOAT(10, 6))
  BEGIN

DECLARE _coordinate POINT;
SET _coordinate = GeomFromText(CONCAT('POINT(',_lat, ' ', _lng,')'));

      UPDATE system
      LEFT JOIN address ON address_id = address.id  
      SET ip_address = INET_ATON(_ip_address),
		  client_id =_client_id,
		  on_top_10m = _on_top_10m,
          washing = _washing,
		  dryer = _dryer,
		  control = _control,
		  switch_cabinet = _switch_cabinet,
		  display = _display,
		  qt = _qt,
	      image = _image,
		  link = _link,
          description_intern = _description_intern,
          description_extern = _description_extern,
          street = _street,
          street_nr = _street_nr,
          postcode = _postcode,
          region = _region,
          town = _town,
          number = _number,
          coordinate = _coordinate
      WHERE system.id = _id;

END;
