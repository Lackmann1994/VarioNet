CREATE PROCEDURE delete_system(IN `_id` INT)
  BEGIN

	DELETE FROM system WHERE id= _id;

END;
