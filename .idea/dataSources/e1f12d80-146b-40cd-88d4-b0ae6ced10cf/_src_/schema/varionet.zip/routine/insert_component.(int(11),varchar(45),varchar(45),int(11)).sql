CREATE PROCEDURE insert_component(IN `_system_id` INT, IN `_type` VARCHAR(45), IN `_name` VARCHAR(45), IN `_number` INT)
  BEGIN

INSERT 
	INTO component (system_id, type, name, number) 
	VALUES (_system_id, _type, _name, _number);
      
END;
