CREATE PROCEDURE insert_system(IN `_ip_address`         VARCHAR(45), IN `_client_id` INT, IN `_status` INT,
                               IN `_on_top_10m`         INT, IN `_washing` VARCHAR(45), IN `_dryer` VARCHAR(45),
                               IN `_control`            VARCHAR(45), IN `_switch_cabinet` VARCHAR(45),
                               IN `_display`            INT, IN `_qt` INT, IN `_image` INT, IN `_link` VARCHAR(45),
                               IN `_street`             VARCHAR(45), IN `_street_nr` INT, IN `_postcode` INT,
                               IN `_town`               VARCHAR(45), IN `_region` VARCHAR(45), IN `_number` INT,
                               IN `_description_intern` VARCHAR(45), IN `_description_extern` VARCHAR(45),
                               IN `_password_hash`      VARCHAR(255), IN `_lat` FLOAT(10, 6), IN `_lng` FLOAT(10, 6))
  BEGIN

DECLARE _coordinate POINT;
SET _coordinate = GeomFromText(CONCAT('POINT(',_lat, ' ', _lng,')'));

INSERT INTO address (street, street_nr, postcode, town, region, number, coordinate)
	VALUES (_street, _street_nr, _postcode, _town, _region, _number, _coordinate);
INSERT INTO system(ip_address, client_id, status, on_top_10m, 
	washing, dryer, control, switch_cabinet, display, qt, image, link, address_id, description_intern, description_extern, password_hash)
	VALUES(INET_ATON(_ip_address), _client_id, _status, _on_top_10m, 
	_washing, _dryer, _control, _switch_cabinet, _display, _qt, _image, _link, LAST_INSERT_ID(), _description_intern, _description_extern, _password_hash);
   

END;
