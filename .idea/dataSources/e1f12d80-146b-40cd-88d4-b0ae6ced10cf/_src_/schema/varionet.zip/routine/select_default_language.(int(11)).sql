CREATE PROCEDURE select_default_language(IN `_id` INT)
  BEGIN

SELECT `client`.`default_language`
FROM `varionet`.`client`
WHERE `client`.`id` = _id;


END;
