CREATE TRIGGER delete_client_path
BEFORE DELETE ON client
FOR EACH ROW
  BEGIN

	DELETE FROM `varionet`.`client_path`
	WHERE client_id = OLD.id;


END;
