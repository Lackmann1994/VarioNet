CREATE TRIGGER insert_client_path
AFTER INSERT ON client
FOR EACH ROW
  BEGIN
		DECLARE parent_path TEXT DEFAULT '';
        SELECT path into parent_path FROM client_path WHERE id = NEW.super_client;
        INSERT INTO client_path (`client_id`, `path`)
		VALUES(
			NEW.id, CONCAT(IF(LENGTH(parent_path) < 2, '/', parent_path), NEW.id, '/')
        );
	END;
