CREATE TRIGGER update_client_path
BEFORE UPDATE ON client
FOR EACH ROW
  BEGIN
		DECLARE old_path TEXT DEFAULT '';
        DECLARE new_path TEXT DEFAULT '';
        SELECT path INTO old_path FROM client_path WHERE client_id = NEW.id;
        SELECT path INTO new_path FROM client_path WHERE client_id = NEW.super_client;
        UPDATE client_path set path = 
			REPLACE(path, old_path, CONCAT(IF(LENGTH(new_path) < 2, '/', new_path), NEW.id, '/') )
            WHERE LEFT(path, LENGTH(old_path)) = old_path;
		END;
